<template>
  <div class="banner-wrapper w-full">
    <div class="mx-auto">
    <div class="relative h-96 bg-[#44AAE2] overflow-hidden rounded-lg mb-4">
      <div class="absolute inset-0 bg-black bg-opacity-30"></div>
      <div class="absolute inset-0 flex items-center justify-center">
        <button
          class="bg-white text-[#44AAE2] font-bold py-4 px-8 rounded-full text-xl shadow-lg hover:bg-[#44AAE2] hover:text-white transition-colors">
          Click
        </button>
      </div>
    </div>
  </div>
</div>
</template>

<script setup>
// 필요한 경우 여기에 로직을 추가하세요
</script>