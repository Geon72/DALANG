from django.apps import AppConfig


class KakaomapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kakaomap'
