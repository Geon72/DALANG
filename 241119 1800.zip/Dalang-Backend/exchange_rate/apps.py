from django.apps import AppConfig


class ExchangeRateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exchange_rate'
